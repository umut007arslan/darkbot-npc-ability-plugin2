# NpcAbilityPlugin

Blighted Kristallon %10 HP altına düşünce Solaris Plus ability kullanan DarkBot plugin.

Build with `mvn package` or enable GitHub Actions included.