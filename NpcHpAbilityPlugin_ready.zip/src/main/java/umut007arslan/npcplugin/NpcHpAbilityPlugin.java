package umut007arslan.npcplugin;

import eu.darkbot.api.PluginAPI;
import eu.darkbot.api.extensions.Behavior;
import eu.darkbot.api.managers.HeroAPI;
import eu.darkbot.api.managers.AbilityAPI;
import eu.darkbot.api.game.entities.Npc;
import eu.darkbot.api.game.items.SelectableItem;
import eu.darkbot.api.game.enums.Ability;

public class NpcHpAbilityPlugin implements Behavior {

    private final HeroAPI hero;
    private final AbilityAPI ability;

    // NPC HP % kaça düştüğünde ability kullanılsın?
    private static final int HP_THRESHOLD = 10; // %10 altına düşünce

    public NpcHpAbilityPlugin(PluginAPI api) {
        this.hero = api.getAPI(HeroAPI.class);
        this.ability = api.getAPI(AbilityAPI.class);
    }

    @Override
    public void onTick() {

        // Hedef yoksa çık
        if (!(hero.getTarget() instanceof Npc)) return;

        Npc npc = (Npc) hero.getTarget();
        if (!npc.isValid()) return;

        // NPC HP yüzdesi (0-100)
        int hpPercent = npc.getHealth().getHpPercent();

        // HP eşik değerinin üstünde ise bir şey yapma
        if (hpPercent > HP_THRESHOLD) return;

        // Solaris Plus (Incinerate) referansı
        SelectableItem incinerate = ability.getAbility(Ability.INCINERATE);

        if (incinerate != null &&
            incinerate.isAvailable() &&
            !incinerate.isActive()) {

            ability.useAbility(Ability.INCINERATE);
        }
    }
}
